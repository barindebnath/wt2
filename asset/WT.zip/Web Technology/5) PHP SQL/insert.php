<html>
   <body bgcolor="#f8d7da">
      <form action="disp.php">
         <?php
         error_reporting(E_ERROR | E_PARSE); 
         // create a variable
         $first_name=$_POST['first_name'];
         $last_name=$_POST['last_name'];
         $department=$_POST['department'];
         $email=$_POST['email'];
         $connect=mysqli_connect('localhost','username','password','database_name');
         if(mysqli_connect_errno($connect)){
            echo 'Failed to connect';
         }
         //Execute the query
         mysqli_query($connect, "INSERT INTO table_name(first_name,last_name,department,email) VALUES('$first_name','$last_name','$department','$email')");
         ?>
         <input type="submit" value="Display"></input>
      </form>
   </body>
</html>