<head>
  <style>table{border-style:solid;border-width:2px;margin: 20px auto;}</style>
</head>

<body bgcolor="#f8d7da">
  <a href="reg.html">Add New Data</a><br/><br/>
  <?php
  $con = mysql_connect("localhost","username","password");
  if (!$con)
    {
    die('Could not connect: ' . mysql_error());
    }
  mysql_select_db("database_name", $con);
   $result = mysql_query("SELECT * FROM table_name");
   echo "<table border='1'>
  <tr>
  <th>NAME</th>
  <th>AGE</th>
  <th>CITY</th>
  </tr>";
   while($row = mysql_fetch_array($result))
    {
    echo "<tr>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['city'] . "</td>";
    echo "</tr>";
    }
  echo "</table>";
   mysql_close($con);
  ?>
</body>